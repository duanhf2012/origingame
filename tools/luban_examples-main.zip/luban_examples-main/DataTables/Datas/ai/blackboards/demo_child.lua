return {
	name = "demo",
	desc ="demo hahaha",
	parent_name = "demo_parent",
	keys =
	{
		{name="x1",desc="x1 haha", is_static=false, key_type="BOOL", type_class_name=""},
		{name="x2",desc="x2 haha", is_static=false, key_type="INT", type_class_name=""},
		{name="x3",desc="x3 haha", is_static=false, key_type="FLOAT", type_class_name=""},
		{name="x4",desc="x4 haha", is_static=false, key_type="STRING", type_class_name=""},
		{name="x5",desc="x5 haha", is_static=false, key_type="VECTOR", type_class_name=""},
		{name="x6",desc="x6 haha", is_static=false, key_type="ROTATOR", type_class_name=""},
		{name="x7",desc="x7 haha", is_static=false, key_type="NAME", type_class_name=""},
		{name="x8",desc="x8 haha", is_static=false, key_type="CLASS1", type_class_name=""},
		{name="x9",desc="x9 haha", is_static=false, key_type="ENUM1", type_class_name="ABC"},
		{name="x10",desc="x10 haha", is_static=false, key_type="OBJECT", type_class_name="OBJECT"},
	},
}