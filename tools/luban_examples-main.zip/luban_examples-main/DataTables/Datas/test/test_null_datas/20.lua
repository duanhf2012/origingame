return
{
	id=20,
	x1 = nil,
	x2 = nil,
	x3 = nil,
	x4 = nil,
	s1 = nil,
	s2 = nil,
}