#include "ByteBuf.h"

namespace luban
{
    const int ByteBuf::INIT_CAPACITY = 16;
    const byte ByteBuf::EMPTY_BYTES[1] = { '\0' };
}